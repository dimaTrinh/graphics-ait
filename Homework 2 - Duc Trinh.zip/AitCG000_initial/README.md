Completed Features:
1. Selection: 
	Tab pick: using the key "Q" to move to the next object
	Mouse Pick: note that even if the user's click is not near any objects, the program will deselect every object
2. Position manipulation: 
	Arrow Move (Using the Arrow keys)
3. Orientation manipulation: 
	Key rorate (Using the key "A" to turn left, using the key "D" to turn right)
4. Editing: 
	Add New: New object is created at the origin when "N" is pressed
	Delete: Selected object is removed if "DEL" is pressed
5. View: 
	Zoom: "Z" should zoom in, "X" zoom out
	Scroll: The visible window is moved by pressing "I", "J", "K" and "L".
6. Combo:
	Camera & mouse: Mouse operations work even when the camera settings have changed 
	Camera & creation: The new object is placed world space position that is at the middle of the canvas with the current camera settings
7. Hard Ones:
	Working on Parent

	