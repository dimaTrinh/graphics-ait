Completed Features:
1. Directional
2. Point
3. Diffuse 
4. Environment mapping
5. Procedural Normal Mapping 
6. Specular