Completed Features:
1. Background
2. Directional plane-projected shadows
3. Ground
4. First Person Camera (WASD to move character, Q to turn left, E to turn right)
5. Procedural Solid Texturing