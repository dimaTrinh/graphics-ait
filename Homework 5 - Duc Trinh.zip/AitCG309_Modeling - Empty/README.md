Completed Features:
To test things out: Use WASD for movement, and use Q E to rotate CCW/CW
1. Directional 
2. Point (there is one rotating point light on top of the middle slowpoke)
3. Diffuse 
4. Environment mapping (the slow poke to the left)
5. Procedural Normal Mapping (the slowpoke to the right)
6. Specular (the middle slowpoke)