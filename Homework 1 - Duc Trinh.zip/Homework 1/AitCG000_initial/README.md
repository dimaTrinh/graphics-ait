Completed Features:
1. Simple shapes: Donut
2. Parametric shapes: Heart
3. Patterns: Striped
4. Animated Patterns: Hypno
5. Animated Shapes: Waving
6. Events: Arrow Move
7. Games: Dodge'em