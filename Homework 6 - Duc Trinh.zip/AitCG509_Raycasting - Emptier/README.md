Completed Features:
1. Misc
- Environment
2. Quadrics
- Pawns
- King
3. Lighting
- Sun??