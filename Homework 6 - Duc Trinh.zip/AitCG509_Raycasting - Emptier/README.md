Completed Features:
1. Misc
- Environment
- Wood 
- Animation
2. Quadrics
- Pawns
- Kings
- Bishops
3. Lighting
- Sun??
- Gloria (neon light above the King piece)??