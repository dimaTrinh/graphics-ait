Completed Features:
1. Background
2. Directional plane-projected shadows
3. 