Completed tasks:
1. Avatar control: Rocket Science
2. Collisions: Rubberoids
3. Texture animation: Boom
4. Parenting: Flames
5. Spawn: Shoot 'em up