Completed tasks:
1. Avatar control: Rocket Science
2. Collisions: Flipper
3. Texture animation: Boom
4. 